// src/screens/ParticipantMode.jsx

import React from 'react';
export default function ParticipantMode() {
  return <h2>참가자 모드 화면</h2>;
}