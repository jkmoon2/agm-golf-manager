// src/screens/AdminMode.jsx

import React from 'react';
export default function AdminMode() {
  return <h2>운영자 모드 화면</h2>;
}