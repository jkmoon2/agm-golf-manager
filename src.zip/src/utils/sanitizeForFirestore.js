// src/utils/sanitizeForFirestore.js

export function sanitizeForFirestore(value) {
  if (value === undefined) return null;
  if (value === null) return null;

  if (Array.isArray(value)) {
    return value.map((v) => sanitizeForFirestore(v));
  }

  if (typeof value === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(value)) {
      if (v === undefined) out[k] = null;
      else out[k] = sanitizeForFirestore(v);
    }
    return out;
  }

  return value;
}
